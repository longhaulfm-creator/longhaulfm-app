import { useEffect } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { NowPlaying } from '@/components/NowPlaying'
import { BroadcastControls } from '@/components/BroadcastControls'
import { useBroadcastStore } from '@/stores/broadcastStore'

export const Route = createFileRoute('/')({
  component: Dashboard,
})

function StatPill({ label, value, colour }: { label: string; value: string; colour?: string }) {
  return (
    <div className="bg-brand border border-white/5 rounded px-2 py-1 flex flex-col justify-center min-w-0 h-11">
      <span className="font-ui text-[7px] font-bold tracking-widest uppercase text-white/30 truncate leading-none">{label}</span>
      <span className="font-header text-base tracking-wide truncate leading-none mt-0.5" style={{ color: colour ?? '#DAA520' }}>{value}</span>
    </div>
  )
}

function Dashboard() {
  const { state, fetchInitial, subscribeRealtime } = useBroadcastStore()

  useEffect(() => {
    fetchInitial()
    const unsub = subscribeRealtime()
    return () => unsub()
  }, [])

  return (
    <div className="h-screen w-screen flex flex-col bg-brand-dark p-2 overflow-hidden">
      
      {/* 1. Header - Tightened significantly */}
     <header className="flex flex-col items-center justify-center shrink-0 mb-3">
        <div className="flex items-center gap-3">
           <svg
    xmlns="http://www.w3.org/2000/svg"
    width="48"
    height="48"
    viewBox="0 0 400 400"
  >
    <circle
      cx="200"
      cy="200"
      r="180"
      fill="#1B3A52"
      stroke="#DAA520"
      strokeWidth="8"
    ></circle>
    <path
      stroke="#DAA520"
      strokeLinecap="round"
      strokeWidth="6"
      d="M200 120V80"
    ></path>
    <path
      fill="none"
      stroke="#DAA520"
      strokeLinecap="round"
      strokeWidth="5"
      d="M160 140q40-25 80 0"
    ></path>
    <path
      fill="none"
      stroke="#DAA520"
      strokeLinecap="round"
      strokeWidth="5"
      d="M140 165q60-45 120 0"
    ></path>
    <path
      fill="none"
      stroke="#DAA520"
      strokeLinecap="round"
      strokeWidth="5"
      d="M120 190q80-65 160 0"
    ></path>
    <text
      x="200"
      y="245"
      fill="#DAA520"
      fontFamily="Arial Black, sans-serif"
      fontSize="56"
      fontWeight="900"
      textAnchor="middle"
    >
      FM
    </text>
    <text
      x="200"
      y="310"
      fill="#FFF"
      fontFamily="Arial Black, sans-serif"
      fontSize="36"
      fontWeight="900"
      letterSpacing="2"
      textAnchor="middle"
    >
      LONG HAUL
    </text>
  </svg>
           <h1 className="font-header text-lg text-white tracking-[0.2em] uppercase">Long Haul FM</h1>
        </div>
        <p className="font-ui text-[8px] text-gold/60 tracking-[0.4em] uppercase mt-1">For the Brotherhood of the Road</p>
      </header>
{/* Stats - Grid optimized for mobile */}
      <div className="grid grid-cols-2 gap-2 shrink-0 mb-3">
        <StatPill label="Listeners" value={(state?.listener_count ?? 0).toLocaleString()} colour="#25d366" />
        <StatPill label="On Air" value={state?.is_on_air ? 'YES' : 'OFF'} colour={state?.is_on_air ? '#25d366' : '#ff1744'} />
      </div>

      {/* Hero Monitor - Expanded space */}
      <div className="flex-1 min-h-0 mb-3 relative">
         <NowPlaying />
      </div>

      {/* Secure Session / Engage Footer */}
      <div className="shrink-0 space-y-3 bg-brand-dark pt-1">
        <BroadcastControls />
      </div>
    </div>
  )
}