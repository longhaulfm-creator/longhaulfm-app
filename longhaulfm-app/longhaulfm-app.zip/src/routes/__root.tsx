// src/routes/__root.tsx
import { createRootRoute, Outlet } from '@tanstack/react-router'
import { useEffect } from 'react'
import { useBroadcastStore } from '@/stores/broadcastStore'
import { useAlertStore } from '@/stores/alertStore'

export const Route = createRootRoute({
  component: RootComponent,
})

function RootComponent() {
  const fetchInitial = useBroadcastStore(s => s.fetchInitial)
  const subscribeBroadcast = useBroadcastStore(s => s.subscribeRealtime)
  const fetchAlerts = useAlertStore(s => s.fetchAlerts)

  useEffect(() => {
    fetchInitial()
    fetchAlerts()
    const unsubBroadcast = subscribeBroadcast()

    return () => {
      if (typeof unsubBroadcast === 'function') {
        unsubBroadcast()
      }
    }
  }, [fetchInitial, fetchAlerts, subscribeBroadcast])

  return (
    /* 1. bg-brand-dark: The deep teal from the poster
       2. font-body: Barlow (Clean and readable for driving)
       3. antialiased: Better text rendering on Android WebViews
    */
    <main className="h-screen w-screen bg-brand-dark text-white font-body antialiased overflow-hidden flex flex-col">
      <Outlet />
    </main>
  )
}