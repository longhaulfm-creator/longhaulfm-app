import { useEffect, useState } from 'react';
import { useBroadcastStore } from '../stores/broadcastStore';

export const useSpotifyStreaming = (token: string) => {
  const [player, setPlayer] = useState<any>(null);
  const { setNowPlaying } = useBroadcastStore();

  useEffect(() => {
    if (!token) return;

    const script = document.createElement("script");
    script.src = "https://sdk.scdn.co/spotify-player.js";
    script.async = true;
    document.body.appendChild(script);

    (window as any).onSpotifyWebPlaybackSDKReady = () => {
      const newPlayer = new (window as any).Spotify.Player({
        name: 'Station Player', // This is what shows in Spotify devices
        getOAuthToken: cb => { cb(token); },
        volume: 0.5
      });

      // CONNECTION HANDLER
      newPlayer.addListener('ready', ({ device_id }) => {
        console.log('🚛 Station Player Ready with ID:', device_id);
        
        // AUTO-TRANSFER: This forces Spotify to use the Tablet immediately
        fetch('https://api.spotify.com/v1/me/player', {
          method: 'PUT',
          body: JSON.stringify({ device_ids: [device_id], play: true }),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
      });

      // STATE CHANGE HANDLER
      newPlayer.addListener('player_state_changed', (state: any) => {
        if (!state) return;
        setNowPlaying(state);
      });

      newPlayer.connect();
      setPlayer(newPlayer);
    };

    return () => {
      if (player) player.disconnect();
    };
  }, [token]);

  // HELPER FUNCTION FOR BUTTONS
  const togglePlay = () => {
    if (player) player.togglePlay();
  };

  return { player, togglePlay };
};