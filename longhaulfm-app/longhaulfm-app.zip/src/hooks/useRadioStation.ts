import { useEffect } from 'react'
import * as Ably from 'ably'

interface TrackSyncData {
  uri: string
  position_ms: number
  isPlaying: boolean
}

interface MicStateData {
  active: boolean
}

export const useRadioStation = (spotifyPlayer: any) => {
  useEffect(() => {
    // 1. Guard: Don't run if the player isn't initialized yet
    if (!spotifyPlayer) return

    // 2. Initialize Ably (Fast Lane)
    const ably = new Ably.Realtime({ key: import.meta.env.VITE_ABLY_KEY })
    const channel = ably.channels.get('longhaul-live')

    console.log("📡 Connected to Ably: Listening for DJ signals...")

    // --- SIGNAL A: The "Duck" (DJ is speaking) ---
    channel.subscribe('mic-state', (message: Ably.IncompleteMessage) => {
      const data = message.data as MicStateData
      const targetVolume = data.active ? 0.2 : 1.0
      
      spotifyPlayer.setVolume(targetVolume).then(() => {
        console.log(data.active ? "🎤 DJ LIVE: Ducking Audio" : "🎵 Music Restored");
      });
    });

    // --- SIGNAL B: The "Force Play" (DJ changed the track) ---
    channel.subscribe('track-change', (message: Ably.IncompleteMessage) => {
      const data = message.data as TrackSyncData
      
      // We use the Spotify Web Playback SDK internal method to play 
      // This ensures the listener stays perfectly in sync with the DJ's timestamp
      spotifyPlayer._options.getOAuthToken((token: string) => {
        fetch(`https://api.spotify.com/v1/me/player/play`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            uris: [data.uri],
            position_ms: data.position_ms
          }),
        }).catch(err => console.error("Spotify Sync Error:", err));
      });
    });

    // --- CLEANUP ---
    return () => {
      channel.unsubscribe()
      ably.close()
      console.log("📴 Radio Sync Disconnected")
    }
  }, [spotifyPlayer])
}