import { useEffect, useRef } from 'react'
import { useBroadcastStore } from '@/stores/broadcastStore'
import { useSpotifyStreaming } from '@/hooks/useSpotifyStreaming'
import { fmtDuration, SOURCE_CONFIG } from '@/lib/utils'
import { cn } from '@/lib/utils'
import { Play, Pause } from 'lucide-react'

export function NowPlaying() {
  const { nowPlaying, state, elapsed, tickElapsed } = useBroadcastStore()
  // Ensure we are getting the latest playbackState from the hook
  const { playbackState, togglePlay, isReady } = useSpotifyStreaming()
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // 1. Sync Timer Logic
  useEffect(() => {
    // A track is "playing" if the broadcast is on AND Spotify isn't paused
    const isActuallyPlaying = state?.is_on_air && playbackState && !playbackState.paused;
    
    if (isActuallyPlaying) {
      if (!timerRef.current) {
        timerRef.current = setInterval(tickElapsed, 1000)
      }
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [tickElapsed, state?.is_on_air, playbackState?.paused])

  // 2. Playback Action
  const handlePlayback = async () => {
    if (!isReady) return;
    try {
      await togglePlay()
    } catch (err) {
      console.error("Playback toggle failed:", err)
    }
  }

  const source = nowPlaying?.source ?? 'spotify'
  const srcConfig = SOURCE_CONFIG[source]
  const duration = nowPlaying?.duration_secs ?? 0
  const progress = duration > 0 ? Math.min((elapsed / duration) * 100, 100) : 0
  
  // CRITICAL: Robust check for playing status
  const isPlaying = !!(playbackState && !playbackState.paused);

  return (
    <div className="panel flex flex-col h-full bg-brand/30 overflow-hidden relative border-white/5 shadow-2xl">
      <div className="panel-header py-1.5 px-4 shrink-0 flex justify-between bg-black/40">
        <span className="font-header text-[10px] tracking-widest text-gold uppercase">Monitor</span>
        <span className="font-ui text-[10px] font-bold text-whatsapp uppercase tracking-widest">
          {srcConfig.label}
        </span>
      </div>

      <div className="flex flex-col flex-1 p-4 justify-between min-h-0">
        <div className="relative w-full max-h-[160px] aspect-square mx-auto shrink mb-2">
          <div className="relative h-full aspect-square mx-auto rounded-lg bg-black/60 border border-gold/15 overflow-hidden shadow-2xl">
             {nowPlaying?.artwork_url ? (
                <img 
                  src={nowPlaying.artwork_url} 
                  alt="Track Art"
                  className={cn(
                    "w-full h-full object-cover transition-all duration-700", 
                    !isPlaying && "grayscale opacity-30 scale-95"
                  )} 
                />
             ) : (
                <div className="w-full h-full flex items-center justify-center bg-brand-dark">
                   <div className="w-12 h-12 rounded-full border-2 border-gold/10 flex items-center justify-center">
                     <Play size={24} className="text-gold/5 ml-1" />
                   </div>
                </div>
             )}
          </div>
        </div>

        <div className="text-center w-full shrink-0 mb-4">
          <h2 className="font-header text-xl text-white truncate leading-tight uppercase tracking-tight">
            {nowPlaying?.track_title || "STATION IDLE"}
          </h2>
          <p className="font-ui text-gold uppercase tracking-[0.2em] text-[10px] mt-1 opacity-70">
            {nowPlaying?.track_artist || "LONG HAUL RADIO"}
          </p>
        </div>

        <div className="w-full shrink-0 space-y-6">
          <button 
            onClick={handlePlayback}
            disabled={!isReady}
            className={cn(
              "w-full h-14 flex gap-3 items-center justify-center font-header text-xl rounded-md transition-all active:scale-95 shadow-lg",
              !isReady ? "bg-white/10 text-white/20 cursor-not-allowed" : 
              isPlaying ? "bg-signal-red text-white border-b-4 border-red-900" : "bg-gold text-brand-dark border-b-4 border-amber-700"
            )}
          >
            {!isReady ? (
              "INITIALIZING..." 
            ) : isPlaying ? (
              <><Pause size={20} fill="currentColor" /> PAUSE</>
            ) : (
              <><Play size={20} fill="currentColor" /> LISTEN LIVE</>
            )}
          </button>

          <div className="space-y-1">
            <div className="w-full h-1 bg-black/60 rounded-full overflow-hidden">
               <div 
                 className="h-full bg-gold transition-all duration-1000 ease-linear" 
                 style={{ width: `${progress}%` }} 
               />
            </div>
            <div className="flex justify-between font-mono text-[8px] text-white/20 uppercase tracking-tighter">
               <span>{fmtDuration(elapsed)}</span>
               <span>{fmtDuration(duration)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}