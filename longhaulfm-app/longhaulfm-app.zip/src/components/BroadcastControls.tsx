import { useBroadcastStore } from '@/stores/broadcastStore'
import { useAuthStore } from '@/stores/authStore'
import { Radio, Power, Music, ShieldCheck } from 'lucide-react'
import { cn } from '@/lib/utils'
import { open } from '@tauri-apps/plugin-shell';

export function BroadcastControls() {
  const { state, toggleBroadcast } = useBroadcastStore()
  const { spotifyToken } = useAuthStore()

  const handleSpotifyConnect = async () => {
    const CLIENT_ID = import.meta.env.VITE_SPOTIFY_CLIENT_ID
    const redirectUri = "https://glenna-paradigmatical-disillusionedly.ngrok-free.dev/auth/callback";
    const SCOPES = ['streaming', 'user-read-email', 'user-read-private', 'user-modify-playback-state', 'user-read-playback-state'].join(' ')
    const authPath = `https://accounts.spotify.com/authorize`;
    const params = new URLSearchParams({
      client_id: CLIENT_ID,
      response_type: 'code',
      redirect_uri: redirectUri,
      scope: SCOPES,
      show_dialog: 'true'
    });

    const authUrl = `${authPath}?${params.toString()}`;
    
    try {
        await open(authUrl); 
    } catch (err) {
        window.location.assign(authUrl);
    }
  }

  return (
    <footer className="mt-auto bg-brand-dark border-t border-white/10 p-4 pb-6 flex flex-col gap-4 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
      <div className="flex items-center justify-between gap-4">
        
        {/* LEFT SIDE: Connection Status / Spotify Link */}
        {!spotifyToken ? (
          <button 
            onClick={handleSpotifyConnect}
            className="flex-1 flex items-center justify-center gap-2 bg-[#1DB954] hover:bg-[#1ed760] text-black font-header text-sm h-14 rounded-full shadow-[0_0_20px_rgba(29,185,84,0.3)] animate-pulse transition-all"
          >
            <Music size={18} /> LINK STATION SPOTIFY
          </button>
        ) : (
          <div className="flex-1 flex items-center gap-3 bg-brand border border-white/5 p-3 rounded-full h-14 px-5">
            <ShieldCheck className="text-signal-green" size={24} />
            <div className="flex flex-col">
              <span className="font-header text-sm tracking-wider text-white">SECURE SESSION</span>
              <span className="text-[10px] text-white/40 uppercase font-ui">Master Account Active</span>
            </div>
          </div>
        )}

        {/* RIGHT SIDE: The Main Toggle Button */}
        <button
          onClick={toggleBroadcast}
          disabled={!spotifyToken}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 h-14 font-header text-sm tracking-wider rounded-md transition-all duration-500",
            state?.is_on_air 
              ? "bg-signal-red text-white shadow-[0_0_25px_rgba(255,23,68,0.4)]" 
              : "bg-blue-700 text-white shadow-[0_0_20px_rgba(29,78,216,0.5)] hover:bg-blue-600",
            !spotifyToken && "opacity-40 cursor-not-allowed grayscale"
          )}
        >
          {state?.is_on_air ? (
            <><Power size={18} className="animate-pulse" /> END BROADCAST</>
          ) : (
            <><Radio size={18} /> ENGAGE ON-AIR</>
          )}
        </button>
      </div>

      {/* BRANDED SIGN-OFF */}
      <div className="text-center mt-6">
         <p className="text-[10px] font-header text-white tracking-[0.3em] uppercase font-light font-bold">
           By the</p> <p className="font-black font-header   uppercase">Isuhamba Group</p>

      </div>
    </footer>
  )
}