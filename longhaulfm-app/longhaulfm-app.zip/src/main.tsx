import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App' // or your Router provider
import './styles.css'

const rootElement = document.getElementById('root');

if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  )
} else {
  console.error("Could not find root element!");
}