import { create } from 'zustand';
import { supabase } from '../lib/supabase';

interface BroadcastState {
  isPlaying: boolean;
  currentTrack: any | null;
  setNowPlaying: (state: any) => void;
  fetchInitial: () => Promise<void>;
  subscribeRealtime: () => () => void;
}

export const useBroadcastStore = create<BroadcastState>((set) => ({
  isPlaying: false,
  currentTrack: null,

  fetchInitial: async () => {
    try {
      // Changed to 'broadcast_state' to match your screenshot
      const { data, error } = await supabase
        .from('broadcast_state') 
        .select('*')
        .limit(1)
        .maybeSingle();
      
      if (error) {
        console.error("Supabase Error:", error.message);
        return;
      }

      if (data) {
        set({
          isPlaying: data.is_playing,
          // If your column is named differently in broadcast_state, update 'track_data' below
          currentTrack: data.track_data 
        });
      }
    } catch (err) {
      console.error("Fetch Initial Failed:", err);
    }
  },

  subscribeRealtime: () => {
    const channel = supabase
      .channel('broadcast-updates')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'broadcast_state' // Changed to match your screenshot
      }, (payload) => {
        if (payload.new) {
          const newData = payload.new as any;
          set({
            isPlaying: newData.is_playing,
            currentTrack: newData.track_data
          });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },

  setNowPlaying: (state: any) => {
    const track = state?.track_window?.current_track;
    if (!track) return;

    set({
      isPlaying: !state.paused,
      currentTrack: {
        title: track.name || "Unknown",
        artists: track.artists?.map((a: any) => a.name) || ["Unknown"],
        artwork: track.album?.images?.[0]?.url || "",
        uri: track.uri || ""
      }
    });
  },
}));